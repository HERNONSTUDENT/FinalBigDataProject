CREATE TABLE [dbo].[Weather_Raw_PY] (

	[city] varchar(8000) NULL, 
	[datetime] datetime2(6) NULL, 
	[temperature_celsius] float NULL, 
	[humidity] bigint NULL, 
	[wind_speed] float NULL, 
	[weather_description] varchar(8000) NULL
);