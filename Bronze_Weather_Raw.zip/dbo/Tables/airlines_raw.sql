CREATE TABLE [dbo].[airlines_raw] (

	[IATA_CODE] varchar(8000) NULL, 
	[AIRLINE] varchar(8000) NULL
);