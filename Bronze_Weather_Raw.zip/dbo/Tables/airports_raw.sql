CREATE TABLE [dbo].[airports_raw] (

	[IATA_CODE] varchar(8000) NULL, 
	[AIRPORT] varchar(8000) NULL, 
	[CITY] varchar(8000) NULL, 
	[STATE] varchar(8000) NULL, 
	[COUNTRY] varchar(8000) NULL, 
	[LATITUDE] varchar(8000) NULL, 
	[LONGITUDE] varchar(8000) NULL
);