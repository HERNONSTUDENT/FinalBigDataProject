CREATE TABLE [dbo].[airports_refined] (

	[IATA_CODE] varchar(8000) NULL, 
	[AIRPORT] varchar(8000) NULL, 
	[CITY] varchar(8000) NULL, 
	[STATE] varchar(8000) NULL, 
	[COUNTRY] varchar(8000) NULL, 
	[LATITUDE] float NULL, 
	[LONGITUDE] float NULL
);