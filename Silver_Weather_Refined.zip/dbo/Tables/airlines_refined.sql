CREATE TABLE [dbo].[airlines_refined] (

	[IATA_CODE] varchar(8000) NULL, 
	[AIRLINE] varchar(8000) NULL
);